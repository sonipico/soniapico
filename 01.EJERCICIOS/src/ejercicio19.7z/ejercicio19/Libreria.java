package ejercicio19;

import java.util.ArrayList;



public class Libreria {
	private ArrayList<Libro>listaLibros;

	@Override
	public String toString() {
		return "Lista de libros: " + listaLibros;
	}

	public ArrayList<Libro> getListaLibros() {
		return listaLibros;
	}

	public void setListaLibros(ArrayList<Libro> listaLibros) {
		this.listaLibros = listaLibros;
	}
	public Libro mostrarlbro(String ISBN) {
		for (Libro l : getListaLibros()) {
			if(l.getISBN().equalsIgnoreCase(ISBN)) {
				return l;
			}
		}
		return null;
	}
	public Libro mostrarLibro(String titulo) {
		for(Libro i:getListaLibros()) {
			if(i.getTitulo().equalsIgnoreCase(titulo)) {
				return i;
			}
		}
		return null;
	}
	public Libro mostrarLibroEditotial(String editorial) {
		for(Libro i:getListaLibros()) {
			if(i.getEditorial().equalsIgnoreCase(editorial)) {
				return i;
			}
		}
		return null;
	}
	
	
}
